# Contributing to CI PHPUnit Test

## Testing

There are tests for *CI PHPUnit Test*: https://github.com/kenjis/ci-app-for-ci-phpunit-test/tree/master/application/tests

Please write tests for your code and send Pull Request to it, if you could.

## Documentation

Update documentation if it is needed.

* [README.md](README.md)
* [docs](docs)
